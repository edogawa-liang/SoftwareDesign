package hw1;

public class Dog extends Animal{
	public void sound() {
		System.out.println("Dog barks");
	}
}