package hw1;

public abstract class Animal {
	public abstract void sound();
}