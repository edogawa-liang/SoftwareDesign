package hw1;

public class Cat extends Animal{
	public void sound() {
		System.out.println("Cat meows");
	}
}