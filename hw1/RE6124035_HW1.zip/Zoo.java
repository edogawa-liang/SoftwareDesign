package hw1;

public class Zoo {
	public void animalsound(Animal animal) {
		animal.sound();
	}
}