package hw1;

public class Sheep extends Animal{
	public void sound() {
		System.out.println("Sheep bleats");
	}
}